#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "clib_trie.h"

trie_Node* newNode() {
	trie_Node* new = (trie_Node*)malloc(sizeof(trie_Node));
	new->word = 0;
	for (int i = 0; i < 26; ++i) new->child[i] = 0;
	return new;
}

void trie_insert(trie_Node* root, char* str) {
	int len = strlen(str);
	trie_Node* now = root;

	for (int i = 0; i < len; ++i) {
		if (!now->child[str[i] - 'a']) now->child[str[i] - 'a'] = newNode();
		now = now->child[str[i] - 'a'];
	}
	now->word = 1;
}
int trie_search(trie_Node* root, char* str) {
	int len = strlen(str);
	trie_Node* now = root;

	for (int i = 0; i < len; ++i) {
		if (!now->child[str[i]-'a']) return 0;
		now = now->child[str[i] - 'a'];
	}
	return now->word;
}
void trie_showtree(trie_Node* now, char* str, int depth) {
	if (now->word) printf("%s\n", str);

	for (int i = 0; i < 26; ++i) {
		if (now->child[i]) {
			str[depth] = i + 'a';
			str[depth + 1] = 0;
			trie_showtree(now->child[i], str, depth + 1);
		}
	}
}

int trie_remove(trie_Node* now, char* str, int i) {
	if (i == strlen(str)) {
		int chk = 0;
		for (int i = 0; i < 26; ++i) {
			if (now->child[i]) chk = 1;
		}
		if (chk) return 0;
		return 1;
	}
}