#ifndef __D_TRIE_H__

#define __D_TRIE_H__
#define TRUE    1
#define FALSE   0

typedef struct trie_node {
	struct node* child[26];
	int word;
}trie_Node;

trie_Node* newNode();
void trie_insert(trie_Node* root, char* str);
int trie_search(trie_Node* root, char* str);
void trie_showtree(trie_Node* now, char* str, int depth);
int trie_remove(trie_Node* now, char* str, int i);


#endif